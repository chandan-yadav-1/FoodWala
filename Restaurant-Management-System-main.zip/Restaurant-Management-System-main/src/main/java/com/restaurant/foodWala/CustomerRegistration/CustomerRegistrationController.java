package com.restaurant.foodWala.CustomerRegistration;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/customerRegistration")
public class CustomerRegistrationController {
	
	

}