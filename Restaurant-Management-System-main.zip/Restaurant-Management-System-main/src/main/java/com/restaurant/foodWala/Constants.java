package com.restaurant.foodWala;

public final class Constants {

	public static final String mailBodyAccountCreationSuccess = "Your account registration successful on foodWala. Make your first order now and get 50% off.";
	public static final String mailSubjectAccountCreation = "Account Registration Successful";
	public static final String otpMailBody = "Your OTP Verificaton Number on foodWala : ";
	public static final String otpMailSubject = "OTP for account verificaton";
	
}
