package com.restaurant.foodWala.dao;

public class RestaurantDao {

}
